from asyncio import tasks
import streamlit as st
import requests

API_URL = "http://backend:8085/todos/"

def get_tasks():
    response = requests.get(API_URL)
    return response.json()

def create_tasks():
    todo = {"title": st.session_state["new_task"], "description": st.session_state.get("new_description", "")}
    response = requests.post(API_URL, json=todo)
    if response.status_code == 200:
        st.success("Task created successfully!")
    else:
        st.error("Error creating task")

st.title("Daily Planner")
task = get_tasks()

for task in tasks:
    st.write(f"{task['title']} - {task['description']}")

st.text_input("Title", key="new_task")
st.text_input("Description", key="new_description")
st.button("Add Task", on_click=create_tasks)


if __name__ == "__main__":
    #st.set_page_config(layout="wide")
    st.write("Welcome!")
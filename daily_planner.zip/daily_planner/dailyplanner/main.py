from fastapi import FastAPI
from .database import engine, init_db
from .models import SQLModel, Task
from .crud import task_router

app = FastAPI()

@app.on_event("startup")
def on_startup():
    init_db()

app.include_router(task_router)

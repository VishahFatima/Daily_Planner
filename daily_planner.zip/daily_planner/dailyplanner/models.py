from sqlmodel import SQLModel, Field
from typing import Optional

class TaskBase(SQLModel):
    title: str
    description: Optional[str] = None

class TaskCreate(TaskBase):
    pass

class TaskRead(TaskBase):
    id: int

class TaskUpdate(TaskBase):
    pass

class Task(TaskBase, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)

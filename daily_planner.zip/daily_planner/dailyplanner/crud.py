from fastapi import APIRouter, Depends, HTTPException
from sqlmodel import Session, select
from .database import get_session
from .models import Task, TaskCreate, TaskRead, TaskUpdate

task_router = APIRouter()

@task_router.post("/tasks/", response_model=TaskRead)
def create_task(*, session: Session = Depends(get_session), task: TaskCreate):
    db_task = Task.from_orm(task)
    session.add(db_task)
    session.commit()
    session.refresh(db_task)
    return db_task

@task_router.get("/task/{task_id}", response_model=TaskRead)
def read_task(*, session: Session = Depends(get_session), task_id: int):
    db_task = session.get(Task, task_id)
    if not db_task:
        raise HTTPException(status_code=404, detail="Task not found")
    return db_task

@task_router.get("/task/", response_model=list[TaskRead])
def read_tasks(*, session: Session = Depends(get_session)):
    tasks = session.exec(select(Task)).all()
    return tasks

@task_router.put("/task/{task_id}", response_model=TaskRead)
def update_task(*, session: Session = Depends(get_session), task_id: int, task: TaskUpdate):
    db_task = session.get(Task, task_id)
    if not db_task:
        raise HTTPException(status_code=404, detail="Task not found")
    task_data = task.dict(exclude_unset=True)
    for key, value in task_data.items():
        setattr(db_task, key, value)
    session.add(db_task)
    session.commit()
    session.refresh(db_task)
    return db_task

@task_router.delete("/task/{task_id}", response_model=TaskRead)
def delete_task(*, session: Session = Depends(get_session), task_id: int):
    db_task = session.get(Task, task_id)
    if not db_task:
        raise HTTPException(status_code=404, detail="Task not found")
    session.delete(db_task)
    session.commit()
    return db_task

